"""Uses an injected in-memory MongoDB test double, not a live database."""
import mongomock
import pytest
from backend import app
from backend.routes import songs_list

@pytest.fixture
def api():
    store = mongomock.MongoClient().songs.songs
    store.create_index('id', unique=True)
    store.insert_many([dict(song) for song in songs_list])
    app.config['SONG_COLLECTION'] = store
    yield app.test_client()
    app.config.pop('SONG_COLLECTION', None)

def test_read_and_count(api):
    assert api.get('/count').json == {'length': 20}
    assert len(api.get('/song').json) == 20
    assert api.get('/song/1').json['id'] == 1
    assert api.get('/song/99999').status_code == 404

def test_crud_roundtrip(api):
    song = {'id': 323, 'title': 'Test song', 'lyrics': 'Original lyrics'}
    created = api.post('/song', json=song)
    assert created.status_code == 201
    assert '$oid' in created.json['inserted id']
    assert api.get(created.headers['Location']).json['title'] == 'Test song'
    duplicate = api.post('/song', json=song)
    assert duplicate.status_code == 302
    assert duplicate.json['Message'] == 'song with id 323 already present'
    assert api.get('/count').json['length'] == 21
    changed = api.put('/song/323', json={'lyrics': 'Updated'})
    assert changed.status_code == 201
    assert changed.json['lyrics'] == 'Updated'
    assert changed.json['title'] == 'Test song'
    assert api.put('/song/323', json={'lyrics': 'Updated'}).status_code == 200
    deleted = api.delete('/song/323')
    assert deleted.status_code == 204 and deleted.data == b''
    assert api.get('/song/323').status_code == 404
    assert api.get('/count').json['length'] == 20

def test_invalid_and_missing(api):
    assert api.post('/song', json=[]).status_code == 400
    assert api.post('/song', json={'id': '323'}).status_code == 400
    assert api.put('/song/1', json={'id': 2}).status_code == 400
    assert api.put('/song/99999', json={'lyrics': 'Unknown'}).status_code == 404
    assert api.delete('/song/99999').status_code == 404
