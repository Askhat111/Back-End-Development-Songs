"""MongoDB-backed Songs API for the IBM capstone."""
import json
import os
from pathlib import Path
from urllib.parse import quote_plus
from bson import json_util
from flask import jsonify, request, url_for
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError, PyMongoError
from . import app

with (Path(__file__).parent / 'data' / 'songs.json').open(encoding='utf-8') as stream:
    songs_list = json.load(stream)
service = os.environ.get('MONGODB_SERVICE', 'localhost')
port = os.environ.get('MONGODB_PORT')
if port and ':' not in service:
    service = f'{service}:{port}'
username = os.environ.get('MONGODB_USERNAME')
password = os.environ.get('MONGODB_PASSWORD')
credentials = f'{quote_plus(username)}:{quote_plus(password)}@' if username and password else ''
mongo_uri = os.environ.get('MONGODB_URI', f'mongodb://{credentials}{service}')
# Do not log the URI, which can contain credentials. Connection is lazy.
client = MongoClient(mongo_uri, serverSelectionTimeoutMS=5000)
db = client.songs
_seeded = False

def parse_json(value):
    return json.loads(json_util.dumps(value))

def collection():
    global _seeded
    injected = app.config.get('SONG_COLLECTION')
    if injected is not None:
        return injected
    target = db.songs
    if not _seeded:
        target.create_index('id', unique=True)
        if target.count_documents({}) == 0:
            target.insert_many([dict(song) for song in songs_list])
        _seeded = True
    return target

@app.errorhandler(PyMongoError)
def database_unavailable(error):
    app.logger.error('MongoDB operation failed: %s', type(error).__name__)
    return jsonify(message='Song database is unavailable'), 503

@app.route('/health')
def health():
    return jsonify(status='OK'), 200

@app.route('/count')
def count():
    return jsonify(length=collection().count_documents({})), 200

@app.route('/song', methods=['GET'])
def get_songs():
    return jsonify(parse_json(list(collection().find({}).sort('id', 1)))), 200

@app.route('/song/<int:id>', methods=['GET'])
def get_song_by_id(id):
    song = collection().find_one({'id': id})
    if song is None:
        return jsonify(message='song not found'), 404
    return jsonify(parse_json(song)), 200

@app.route('/song', methods=['POST'])
def create_song():
    song = request.get_json(silent=True)
    if not isinstance(song, dict) or type(song.get('id')) is not int:
        return jsonify(message='A JSON song with an integer id is required'), 400
    if not isinstance(song.get('title'), str) or not isinstance(song.get('lyrics'), str):
        return jsonify(message='Song title and lyrics must be strings'), 400
    target = collection()
    if target.find_one({'id': song['id']}) is not None:
        return jsonify(Message=f"song with id {song['id']} already present"), 302
    song.pop('_id', None)
    try:
        result = target.insert_one(song)
    except DuplicateKeyError:
        return jsonify(Message=f"song with id {song['id']} already present"), 302
    response = jsonify(parse_json({'inserted id': result.inserted_id}))
    response.status_code = 201
    response.headers['Location'] = url_for('get_song_by_id', id=song['id'])
    return response

@app.route('/song/<int:id>', methods=['PUT'])
def update_song(id):
    changes = request.get_json(silent=True)
    if not isinstance(changes, dict):
        return jsonify(message='A JSON song is required'), 400
    if 'id' in changes and changes['id'] != id:
        return jsonify(message='The song id must match the URL'), 400
    changes.pop('_id', None)
    if any(key in changes and not isinstance(changes[key], str) for key in ('title', 'lyrics')):
        return jsonify(message='Song title and lyrics must be strings'), 400
    target = collection()
    result = target.update_one({'id': id}, {'$set': changes})
    if result.matched_count == 0:
        return jsonify(message='song not found'), 404
    if result.modified_count == 0:
        return jsonify(message='song found, but nothing updated'), 200
    # Match the lab's worked example (201 for a changed existing song).
    return jsonify(parse_json(target.find_one({'id': id}))), 201

@app.route('/song/<int:id>', methods=['DELETE'])
def delete_song(id):
    result = collection().delete_one({'id': id})
    if result.deleted_count == 0:
        return jsonify(message='song not found'), 404
    return '', 204
